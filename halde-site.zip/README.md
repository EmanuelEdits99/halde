# HALDE — אתר רהיטים

Static website (Hebrew, RTL). No build step.

- `index.html` – homepage
- `collection.html` – all products (`?cat=sofas|chairs|tables|storage|lighting`, `?q=search`)
- `product.html?id=…` – product page
- `cart.html` – cart → sends the order as a WhatsApp message

## Edit products, prices & contact details
Everything lives at the top of `assets/js/app.js`:
- `CONFIG` – WhatsApp number (international format, e.g. `972512345678`), phone, email, hours, address
- `PRODUCTS` – name, price, category, image, description, dimensions

Images are in `assets/img/`.

## Deploy
Import this repo in Vercel (Framework preset: **Other**, no build command, output directory: root). Every push to `main` redeploys.
