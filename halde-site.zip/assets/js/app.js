/* HALDE — site logic: products, cart (localStorage), WhatsApp checkout */
(function () {
  'use strict';

  var CONFIG = {
    brand: 'הלדה',
    whatsapp: '972512345678',      // international format, digits only
    phoneDisplay: '051-2345678',
    phoneTel: '0512345678',
    email: 'support@halde.co.il',
    hours: '8:00–19:00',
    address: 'רחוב הרכבת 30, תל אביב'
  };
  var IMG = 'assets/img/';

  var PRODUCTS = [
    { id: 'arlo', name: 'ספה תלת־מושבית ארלו', cat: 'ספות', key: 'sofas', price: 5490, img: 'sofa-arlo.jpg', tag: 'חדש', material: 'אריג', tex: 'tex-linen.svg', color: 'בהיר',
      desc: 'ספה רחבה ונינוחה עם שלוש כריות מושב עמוקות ומסגרת עץ דקה בגוון אגוז. מספיק מקום לכל המשפחה — ועדיין נראית קלה בחדר.',
      dims: { 'רוחב': '214 ס״מ', 'עומק': '92 ס״מ', 'גובה': '82 ס״מ', 'גובה מושב': '44 ס״מ' }, fabric: 'אריג טקסטורה בגוון שמנת', legs: 'עץ בגוון אגוז' },
    { id: 'arlo-corner', name: 'ספה פינתית ארלו', cat: 'ספות', key: 'sofas', price: 7490, img: 'sofa-corner.jpg', material: 'אריג', tex: 'tex-linen.svg', color: 'בהיר',
      desc: 'הגרסה הפינתית של ארלו, עם שזלונג נוח לשכיבה מול סרט. גב רך, ידיות מעוגלות ורגלי עץ מחודדות.',
      dims: { 'רוחב': '268 ס״מ', 'עומק שזלונג': '165 ס״מ', 'גובה': '82 ס״מ', 'גובה מושב': '44 ס״מ' }, fabric: 'אריג טקסטורה בגוון שמנת', legs: 'עץ בגוון אגוז' },
    { id: 'mira', name: 'ספה דו־מושבית מירה', cat: 'ספות', key: 'sofas', price: 4290, img: 'sofa-mira.jpg', tag: 'אחרונים במלאי', material: 'אריג', tex: 'tex-leather.svg', color: 'קוניאק וקאמל',
      desc: 'ספה דו־מושבית עם קווים מעוגלים וגב שעוטף. גוון קאמל חם שמכניס צבע לחדר — מתאימה גם לסלון קטן.',
      dims: { 'רוחב': '168 ס״מ', 'עומק': '86 ס״מ', 'גובה': '78 ס״מ', 'גובה מושב': '45 ס״מ' }, fabric: 'אריג בגוון קאמל', legs: 'עץ בגוון אגוז כהה' },
    { id: 'linnea', name: 'כורסת לינאה', cat: 'כורסאות', key: 'chairs', price: 2490, img: 'armchair-linnea.jpg', material: 'בוקלה', tex: 'tex-boucle.svg', color: 'בהיר',
      gallery: ['armchair-linnea.jpg', 'room-hero.jpg', 'room-sideboard.jpg', 'tex-boucle.svg', 'tex-walnut.svg'],
      desc: 'כורסה עגולה ונמוכה עם ידיות רכות שעוטפות את הגוף, על רגלי עץ מחודדות. מושב עמוק לקריאה, לקפה של הבוקר או לסוף יום ארוך.',
      dims: { 'רוחב': '84 ס״מ', 'עומק': '82 ס״מ', 'גובה': '76 ס״מ', 'גובה מושב': '42 ס״מ' }, fabric: 'בוקלה בגוון שנהב', legs: 'עץ בגוון אגוז' },
    { id: 'pell', name: 'כורסת עור פל', cat: 'כורסאות', key: 'chairs', price: 3290, img: 'armchair-pell.jpg', material: 'עור', tex: 'tex-leather.svg', color: 'קוניאק וקאמל',
      desc: 'כורסת עור בגוון קוניאק עם גב גבוה ותפרים נקיים. העור מתרכך ומקבל פטינה יפה עם השנים.',
      dims: { 'רוחב': '80 ס״מ', 'עומק': '84 ס״מ', 'גובה': '80 ס״מ', 'גובה מושב': '43 ס״מ' }, fabric: 'עור בגוון קוניאק', legs: 'עץ בגוון אגוז' },
    { id: 'nord', name: 'שולחן קפה נורד', cat: 'שולחנות', key: 'tables', price: 1490, img: 'coffee-nord.jpg', material: 'עץ', tex: 'tex-walnut.svg', color: 'חום ואגוז',
      desc: 'שולחן קפה אובלי ונמוך עם רגליים מעוצבות בזווית. משטח עץ חם שמתאים גם לספות בהירות וגם לכהות.',
      dims: { 'אורך': '120 ס״מ', 'רוחב': '65 ס״מ', 'גובה': '35 ס״מ' }, fabric: '—', legs: 'עץ בגוון אגוז' },
    { id: 'sela', name: 'כיסא אוכל סלה', cat: 'כיסאות', key: 'tables', price: 590, img: 'chair-sela.jpg', material: 'עץ', tex: 'tex-walnut.svg', color: 'חום ואגוז', hidden: false,
      gallery: ['chair-sela.jpg', 'room-hero.jpg', 'tex-walnut.svg'],
      desc: 'כיסא אוכל קלאסי עם משענת מעוגלת ומושב מעוצב לישיבה נוחה. נראה טוב לבד, ועוד יותר טוב בסט סביב השולחן.',
      dims: { 'רוחב': '48 ס״מ', 'עומק': '52 ס״מ', 'גובה': '78 ס״מ', 'גובה מושב': '45 ס״מ' }, fabric: '—', legs: 'עץ בגוון אגוז' },
    { id: 'hale', name: 'ספסל הייל', cat: 'ספסלים', key: 'tables', price: 1190, img: 'bench-hale.jpg', material: 'עץ', tex: 'tex-walnut.svg', color: 'חום ואגוז',
      desc: 'ספסל עץ עם כרית ישיבה מאריג בהיר. מתאים לכניסה לבית, לצד שולחן האוכל או בקצה המיטה.',
      dims: { 'אורך': '150 ס״מ', 'עומק': '38 ס״מ', 'גובה': '45 ס״מ' }, fabric: 'כרית מאריג בהיר', legs: 'עץ בגוון אלון כהה' },
    { id: 'tove', name: 'מזנון טובה', cat: 'אחסון', key: 'storage', price: 3690, img: 'sideboard-tove.jpg', tag: 'חדש', material: 'עץ', tex: 'tex-walnut.svg', color: 'חום ואגוז',
      gallery: ['sideboard-tove.jpg', 'room-sideboard.jpg', 'room-hero.jpg', 'tex-walnut.svg'],
      desc: 'מזנון נמוך וארוך עם שלוש דלתות וידיות מתכת עדינות. מקום לכל מה שצריך בסלון — ומשטח יפה לאגרטל ולספרים.',
      dims: { 'רוחב': '180 ס״מ', 'עומק': '45 ס״מ', 'גובה': '60 ס״מ' }, fabric: '—', legs: 'עץ בגוון אלון־אגוז' },
    { id: 'rune', name: 'ספריית רונה', cat: 'אחסון', key: 'storage', price: 2390, img: 'bookcase-rune.jpg', material: 'עץ', tex: 'tex-walnut.svg', color: 'חום ואגוז',
      desc: 'ספרייה פתוחה עם ארבעה מדפים רחבים, לספרים, לכלים ולצמחים. קווים ישרים ונקיים שמשתלבים בכל חדר.',
      dims: { 'רוחב': '110 ס״מ', 'עומק': '35 ס״מ', 'גובה': '180 ס״מ' }, fabric: '—', legs: 'עץ בגוון אגוז' },
    { id: 'ivo', name: 'מנורת רצפה איבו', cat: 'תאורה', key: 'lighting', price: 890, img: 'lamp-ivo.jpg', material: 'מתכת', tex: '', color: 'חום ואגוז',
      gallery: ['lamp-ivo.jpg', 'room-hero.jpg'],
      desc: 'מנורת קשת עם עמוד מתכת בגוון ברונזה ואהיל פשתן בהיר שמפזר אור רך. מושלמת ליד כורסה או ספה.',
      dims: { 'גובה': '175 ס״מ', 'קוטר אהיל': '40 ס״מ', 'קוטר בסיס': '28 ס״מ' }, fabric: 'אהיל פשתן', legs: 'מתכת בגוון ברונזה' }
  ];

  var fmt = function (n) { return '₪' + Number(n).toLocaleString('en-US'); };
  var byId = function (id) { for (var i = 0; i < PRODUCTS.length; i++) if (PRODUCTS[i].id === id) return PRODUCTS[i]; return null; };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var waLink = function (text) { return 'https://wa.me/' + CONFIG.whatsapp + (text ? '?text=' + encodeURIComponent(text) : ''); };

  /* ---------- cart ---------- */
  var KEY = 'halde-cart-v1';
  function readCart() { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; } }
  function writeCart(c) { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {} updateBadges(); }
  function cartCount() { return readCart().reduce(function (a, x) { return a + x.qty; }, 0); }
  function addToCart(id, qty) {
    var c = readCart(), found = false;
    c.forEach(function (x) { if (x.id === id) { x.qty = Math.min(9, x.qty + (qty || 1)); found = true; } });
    if (!found) c.push({ id: id, qty: qty || 1 });
    writeCart(c);
    var p = byId(id); showToast(p, qty || 1);
  }
  function updateBadges() { var n = cartCount(); document.querySelectorAll('[data-cart-count]').forEach(function (el) { el.textContent = n; }); }

  /* ---------- icons ---------- */
  var ICON = {
    bag: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M5 8h14l-1 12H6L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>',
    search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>',
    menu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M3 7h18M3 12h18M9 17h12"/></svg>',
    wa: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><path d="M4 20l1.3-4A8 8 0 1 1 8 18.7L4 20Z"/></svg>',
    phone: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1Z"/></svg>',
    arrow: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
    arch: '<svg width="22" height="26" viewBox="0 0 22 26" fill="none" stroke="#A9541A" stroke-width="1.7" aria-hidden="true"><path d="M2 25V11a9 9 0 0 1 18 0v14"/><path d="M7 25V12a4 4 0 0 1 8 0v13"/></svg>',
    x: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>'
  };
  window.HALDE_ICON = ICON;

  /* ---------- shared header / footer ---------- */
  function header(active) {
    var nav = [['collection.html?cat=sofas', 'ספות', 'sofas'], ['collection.html?cat=chairs', 'כורסאות', 'chairs'], ['collection.html?cat=tables', 'שולחנות וכיסאות', 'tables'], ['collection.html?cat=storage', 'אחסון ותאורה', 'storage'], ['index.html#about', 'אודות', 'about']];
    var links = nav.map(function (n) { return '<a href="' + n[0] + '"' + (active === n[2] ? ' class="active"' : '') + '>' + n[1] + '</a>'; }).join('');
    return '' +
      '<div class="topbar"><div class="wrap"><span>משלוח והרכבה חינם תוך 3–7 ימים · הזמנה ותשלום בוואטסאפ</span>' +
      '<div class="hide-m" style="display:flex;gap:24px"><span>שירות לקוחות · ' + CONFIG.hours + '</span><a href="tel:' + CONFIG.phoneTel + '" dir="ltr">' + CONFIG.phoneDisplay + '</a></div></div></div>' +
      '<header class="header"><div class="wrap">' +
      '<nav class="nav" aria-label="ניווט ראשי">' + links + '</nav>' +
      '<button class="icon-btn menu-btn" type="button" aria-label="פתיחת תפריט" data-open-menu>' + ICON.menu + '</button>' +
      '<a class="logo" href="index.html" aria-label="הלדה — דף הבית">' + ICON.arch + '<span>HALDE</span></a>' +
      '<div class="header-tools">' +
      '<form class="search" action="collection.html" role="search">' + ICON.search + '<input name="q" type="search" placeholder="חיפוש: ספה, כורסה, מזנון…" aria-label="חיפוש רהיטים"></form>' +
      '<a class="icon-btn" href="cart.html" aria-label="סל קניות">' + ICON.bag + '<span class="hide-m">הסל שלי</span><span class="badge" data-cart-count>0</span></a>' +
      '</div></div></header>' +
      '<div class="mobile-menu" data-menu role="dialog" aria-label="תפריט">' +
      '<button class="icon-btn close" type="button" aria-label="סגירת התפריט" data-close-menu>' + ICON.x + '</button>' +
      '<form class="search" action="collection.html" role="search" style="display:flex;width:100%;margin:8px 0 16px">' + ICON.search + '<input name="q" type="search" placeholder="חיפוש רהיטים…" aria-label="חיפוש רהיטים"></form>' +
      nav.map(function (n) { return '<a class="big" href="' + n[0] + '">' + n[1] + '<span style="color:#A9541A;font-size:20px">←</span></a>'; }).join('') +
      '<div class="bottom"><a class="btn btn-dark" href="' + waLink() + '" target="_blank" rel="noopener">' + ICON.wa + 'כתבו לנו בוואטסאפ</a>' +
      '<a class="btn-ghost" href="tel:' + CONFIG.phoneTel + '">התקשרו: <span dir="ltr">' + CONFIG.phoneDisplay + '</span></a></div></div>';
  }
  function footer() {
    var insta = ['room-sideboard.jpg', 'armchair-linnea.jpg', 'coffee-nord.jpg', 'lamp-ivo.jpg', 'sofa-mira.jpg', 'chair-sela.jpg'];
    return '' +
      '<footer class="footer"><div class="wrap"><div class="footer-grid">' +
      '<div class="col brand"><span class="logo" style="justify-self:start">' + ICON.arch + '<span style="font-size:26px">HALDE</span></span>' +
      '<p class="blurb">רהיטים לבית בעיצוב נקי. אולם תצוגה בתל אביב, משלוח והרכבה חינם לכל הארץ.</p>' +
      '<div class="socials"><a href="#" aria-label="אינסטגרם"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6" fill="currentColor"/></svg></a>' +
      '<a href="#" aria-label="פייסבוק"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M14 21v-8h3l.5-3.5H14V7.5c0-1 .4-1.7 1.8-1.7H18V2.6C17.3 2.5 16.3 2.4 15.2 2.4 12.6 2.4 10.6 4 10.6 7v2.5H8V13h2.6v8"/></svg></a>' +
      '<a href="#" aria-label="פינטרסט"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M11 8.5c3.5-1 5.5 1.2 4.6 3.8-.7 2-3 2.4-4 1.2M11.6 10.5 9.5 20"/></svg></a></div></div>' +
      '<div class="col"><h4>קטגוריות</h4><a href="collection.html?cat=sofas">ספות</a><a href="collection.html?cat=chairs">כורסאות</a><a href="collection.html?cat=tables">שולחנות וכיסאות</a><a href="collection.html?cat=storage">אחסון</a><a href="collection.html?cat=lighting">תאורה</a></div>' +
      '<div class="col"><h4>שירות לקוחות</h4><a href="index.html#faq">משלוחים והרכבה</a><a href="index.html#faq">איך משלמים</a><a href="index.html#faq">החזרות</a><a href="index.html#faq">שאלות נפוצות</a></div>' +
      '<div class="col"><h4>הסטודיו</h4><a href="index.html#about">אודות</a><a href="index.html#materials">חומרים</a><a href="index.html#faq">אחריות</a><a href="index.html#contact">צור קשר</a></div>' +
      '<div class="col insta-col"><h4>עקבו אחרינו @halde</h4><div class="insta">' + insta.map(function (i) { return '<a href="#" aria-label="פוסט באינסטגרם"><img src="' + IMG + i + '" alt="" loading="lazy"></a>'; }).join('') + '</div></div>' +
      '</div><div class="footer-bottom"><span>© ' + new Date().getFullYear() + ' הלדה. כל הזכויות שמורות.</span><div class="links"><a href="#">מדיניות פרטיות</a><a href="#">תקנון</a><a href="#">הצהרת נגישות</a></div></div></div></footer>' +
      '<a class="wa-float" href="' + waLink() + '" target="_blank" rel="noopener" aria-label="שיחה בוואטסאפ">' + ICON.wa + 'שאלה? וואטסאפ</a>' +
      '<div class="toast" role="status" aria-live="polite" data-toast></div>';
  }

  /* ---------- toast ---------- */
  var toastTimer;
  function showToast(p, qty) {
    var el = document.querySelector('[data-toast]'); if (!el || !p) return;
    el.innerHTML = '<div class="top"><span class="ok"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M5 12l5 5 9-10"/></svg></span><b>נוסף לסל</b><button class="x" type="button" aria-label="סגירה" data-close-toast>✕</button></div>' +
      '<div class="row"><span>' + esc(p.name) + (qty > 1 ? ' × ' + qty : '') + '</span><b>' + fmt(p.price * qty) + '</b></div>' +
      '<div class="btns"><button class="btn-ghost" type="button" data-close-toast>המשך קנייה</button><a class="btn" href="cart.html">לסל ולהזמנה</a></div>';
    el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.classList.remove('show'); }, 6000);
  }

  /* ---------- tile ---------- */
  function tile(p) {
    return '<div class="tile">' +
      '<a class="media" href="product.html?id=' + p.id + '"><img src="' + IMG + p.img + '" alt="' + esc(p.name) + '" loading="lazy">' + (p.tag ? '<span class="tag">' + p.tag + '</span>' : '') + '</a>' +
      '<div class="info"><span class="cat-name">' + p.cat + '</span><a class="name" href="product.html?id=' + p.id + '">' + esc(p.name) + '</a><span class="price">' + fmt(p.price) + '</span>' +
      (p.tex ? '<img class="swatch" src="' + IMG + p.tex + '" alt="">' : '') + '</div>' +
      '<button class="btn-ghost add" type="button" data-add="' + p.id + '">' + ICON.bag + 'הוספה לסל</button></div>';
  }

  /* ---------- pages ---------- */
  function initHome() {
    var el = document.querySelector('[data-featured]');
    if (el) el.innerHTML = ['arlo', 'linnea', 'tove', 'sela'].map(function (id) { return tile(byId(id)); }).join('');
    document.querySelectorAll('.faq-q').forEach(function (b) {
      b.addEventListener('click', function () {
        var item = b.closest('.faq-item'), open = item.classList.contains('open');
        document.querySelectorAll('.faq-item').forEach(function (i) { i.classList.remove('open'); i.querySelector('.faq-q').setAttribute('aria-expanded', 'false'); i.querySelector('.sign').textContent = '+'; });
        if (!open) { item.classList.add('open'); b.setAttribute('aria-expanded', 'true'); b.querySelector('.sign').textContent = '−'; }
      });
    });
  }

  function initCollection() {
    var params = new URLSearchParams(location.search);
    var state = { cat: params.get('cat') || 'all', q: (params.get('q') || '').trim(), sort: 'featured', mats: [], colors: [] };
    var tabs = [['all', 'הכול'], ['sofas', 'ספות'], ['chairs', 'כורסאות'], ['tables', 'שולחנות וכיסאות'], ['storage', 'אחסון'], ['lighting', 'תאורה']];
    var titles = { all: 'כל הרהיטים', sofas: 'ספות', chairs: 'כורסאות', tables: 'שולחנות וכיסאות', storage: 'אחסון', lighting: 'תאורה' };
    var tabsEl = document.querySelector('[data-tabs]'), grid = document.querySelector('[data-grid]'), countEl = document.querySelector('[data-count]'), titleEl = document.querySelector('[data-title]'), crumbEl = document.querySelector('[data-crumb]');

    function counts(field) { var m = {}; PRODUCTS.forEach(function (p) { m[p[field]] = (m[p[field]] || 0) + 1; }); return m; }
    function renderFilters() {
      var mc = counts('material'), cc = counts('color');
      var texFor = { 'עץ': 'tex-walnut.svg', 'אריג': 'tex-linen.svg', 'בוקלה': 'tex-boucle.svg', 'עור': 'tex-leather.svg', 'מתכת': 'tex-smoked.svg', 'בהיר': 'tex-boucle.svg', 'חום ואגוז': 'tex-walnut.svg', 'קוניאק וקאמל': 'tex-leather.svg' };
      function box(group, v, n) { return '<label><input type="checkbox" data-filter="' + group + '" value="' + v + '"><img class="sw" src="' + IMG + texFor[v] + '" alt="">' + v + '<span class="n">' + n + '</span></label>'; }
      document.querySelector('[data-f-mat]').innerHTML = Object.keys(mc).map(function (k) { return box('mats', k, mc[k]); }).join('');
      document.querySelector('[data-f-color]').innerHTML = Object.keys(cc).map(function (k) { return box('colors', k, cc[k]); }).join('');
      document.querySelectorAll('[data-filter]').forEach(function (c) {
        c.addEventListener('change', function () { var g = c.getAttribute('data-filter'); state[g] = Array.prototype.map.call(document.querySelectorAll('[data-filter="' + g + '"]:checked'), function (x) { return x.value; }); render(); });
      });
    }
    function render() {
      tabsEl.innerHTML = tabs.map(function (t) { return '<button type="button" class="chip' + (state.cat === t[0] ? ' on' : '') + '" data-cat="' + t[0] + '" aria-pressed="' + (state.cat === t[0]) + '">' + t[1] + '</button>'; }).join('');
      var list = PRODUCTS.filter(function (p) {
        if (state.cat !== 'all' && !(p.key === state.cat || (state.cat === 'storage' && p.key === 'lighting'))) return false;
        if (state.q && (p.name + ' ' + p.cat + ' ' + p.material).indexOf(state.q) === -1) return false;
        if (state.mats.length && state.mats.indexOf(p.material) === -1) return false;
        if (state.colors.length && state.colors.indexOf(p.color) === -1) return false;
        return true;
      });
      if (state.sort === 'low') list.sort(function (a, b) { return a.price - b.price; });
      if (state.sort === 'high') list.sort(function (a, b) { return b.price - a.price; });
      var html = list.map(tile);
      if (state.cat === 'all' && !state.q && !state.mats.length && !state.colors.length && state.sort === 'featured' && html.length > 4) {
        html.splice(4, 0, '<a class="tile feature" href="product.html?id=tove"><img src="' + IMG + 'room-sideboard.jpg" alt="מזנון טובה בסלון" loading="lazy"><div class="box"><span class="eyebrow" style="font-size:14px">השראה</span><span class="name" style="font-family:var(--display);font-size:26px;line-height:1.2">מזנון טובה, נמוך וארוך בסלון</span><span style="font-size:15px;color:var(--body)">לצפייה במוצר ←</span></div></a>');
      }
      grid.innerHTML = html.length ? html.join('') : '<p class="empty-results">לא מצאנו מוצרים שמתאימים לסינון. נסו להסיר חלק מהסינונים.</p>';
      countEl.textContent = list.length + ' מוצרים';
      var t = state.q ? 'תוצאות עבור ״' + state.q + '״' : titles[state.cat];
      titleEl.textContent = t; crumbEl.textContent = t; document.title = t + ' | הלדה';
      tabsEl.querySelectorAll('[data-cat]').forEach(function (b) { b.addEventListener('click', function () { state.cat = b.getAttribute('data-cat'); state.q = ''; history.replaceState(null, '', state.cat === 'all' ? 'collection.html' : 'collection.html?cat=' + state.cat); render(); }); });
    }
    document.querySelector('[data-sort]').addEventListener('change', function (e) { state.sort = e.target.value; render(); });
    var filters = document.querySelector('.filters');
    document.querySelectorAll('[data-open-filters]').forEach(function (b) { b.addEventListener('click', function () { filters.classList.add('open'); }); });
    document.querySelectorAll('[data-close-filters]').forEach(function (b) { b.addEventListener('click', function () { filters.classList.remove('open'); }); });
    renderFilters(); render();
  }

  function initProduct() {
    var id = new URLSearchParams(location.search).get('id') || 'linnea';
    var p = byId(id) || byId('linnea');
    var gallery = (p.gallery || [p.img].concat(p.tex ? [p.tex] : []));
    var view = 0, qty = 1;
    document.title = p.name + ' | הלדה';
    var $ = function (s) { return document.querySelector(s); };
    $('[data-p-crumb-cat]').textContent = p.cat; $('[data-p-crumb-cat]').href = 'collection.html?cat=' + p.key;
    $('[data-p-crumb]').textContent = p.name;
    $('[data-p-cat]').textContent = p.cat;
    $('[data-p-name]').textContent = p.name;
    document.querySelectorAll('[data-p-price]').forEach(function (e) { e.textContent = fmt(p.price); });
    $('[data-p-desc]').textContent = p.desc;
    $('[data-p-spec]').innerHTML = (p.tex ? '<img src="' + IMG + p.tex + '" alt="">' : '') + '<div><b>חומרים:</b> ' + esc(p.fabric !== '—' ? p.fabric + ' · ' : '') + esc(p.legs) + '</div>';
    $('[data-p-dims]').innerHTML = Object.keys(p.dims).map(function (k) { return '<div><dt>' + k + '</dt><dd>' + p.dims[k] + '</dd></div>'; }).join('');
    $('[data-p-mats]').innerHTML = [['חומר עיקרי', p.material], ['בד / ריפוד', p.fabric], ['רגליים / מסגרת', p.legs], ['אחריות', '5 שנים על השלד והחיבורים'], ['משלוח', 'חינם, כולל הרכבה, תוך 3–7 ימים']].map(function (r) { return '<div><dt>' + r[0] + '</dt><dd>' + esc(r[1]) + '</dd></div>'; }).join('');
    $('[data-p-wa]').href = waLink('שלום הלדה, אשמח להזמין: ' + p.name + ' — ' + fmt(p.price));
    function renderGallery() {
      var src = gallery[view];
      $('[data-g-main]').innerHTML = '<img src="' + IMG + src + '" alt="' + esc(p.name) + '">';
      $('[data-g-count]').textContent = (view + 1) + ' / ' + gallery.length;
      $('[data-g-thumbs]').innerHTML = gallery.map(function (g, i) { return '<button type="button" class="' + (i === view ? 'on' : '') + '" data-thumb="' + i + '" aria-label="תמונה ' + (i + 1) + '"><img src="' + IMG + g + '" alt=""></button>'; }).join('');
      document.querySelectorAll('[data-thumb]').forEach(function (b) { b.addEventListener('click', function () { view = +b.getAttribute('data-thumb'); renderGallery(); }); });
    }
    $('[data-g-prev]').addEventListener('click', function () { view = (view - 1 + gallery.length) % gallery.length; renderGallery(); });
    $('[data-g-next]').addEventListener('click', function () { view = (view + 1) % gallery.length; renderGallery(); });
    if (gallery.length < 2) $('.gallery .nav-btns').style.display = 'none';
    renderGallery();
    function renderQty() { $('[data-qty]').textContent = qty; }
    $('[data-inc]').addEventListener('click', function () { qty = Math.min(9, qty + 1); renderQty(); });
    $('[data-dec]').addEventListener('click', function () { qty = Math.max(1, qty - 1); renderQty(); });
    document.querySelectorAll('[data-buy]').forEach(function (b) { b.addEventListener('click', function () { addToCart(p.id, qty); }); });
    var related = PRODUCTS.filter(function (x) { return x.id !== p.id && x.key !== p.key; }).slice(0, 2).concat(PRODUCTS.filter(function (x) { return x.id !== p.id && x.key === p.key; })).slice(0, 4);
    $('[data-related]').innerHTML = related.map(tile).join('');
  }

  function initCart() {
    var info = { name: '', city: '', notes: '' };
    var listEl = document.querySelector('[data-cart-list]'), wrap = document.querySelector('[data-cart-wrap]'), empty = document.querySelector('[data-cart-empty]');
    ['name', 'city', 'notes'].forEach(function (k) { var el = document.querySelector('[data-info="' + k + '"]'); el.addEventListener('input', function () { info[k] = el.value.trim(); renderSummary(); }); });
    function lines() { return readCart().map(function (x) { return { p: byId(x.id), qty: x.qty }; }).filter(function (x) { return x.p; }); }
    function message() {
      var l = lines(), sub = l.reduce(function (a, x) { return a + x.p.price * x.qty; }, 0);
      var m = ['שלום הלדה, אשמח להזמין:'];
      l.forEach(function (x, i) { m.push((i + 1) + '. ' + x.p.name + ' × ' + x.qty + ' — ' + fmt(x.p.price * x.qty)); });
      m.push('סה״כ: ' + fmt(sub) + ' (כולל משלוח והרכבה)');
      if (info.name) m.push('שם: ' + info.name);
      if (info.city) m.push('עיר למשלוח: ' + info.city);
      if (info.notes) m.push('הערות: ' + info.notes);
      return { text: m.join('\n'), sub: sub, count: l.reduce(function (a, x) { return a + x.qty; }, 0) };
    }
    function renderSummary() {
      var m = message();
      document.querySelectorAll('[data-sub]').forEach(function (e) { e.textContent = fmt(m.sub); });
      document.querySelectorAll('[data-items]').forEach(function (e) { e.textContent = m.count; });
      document.querySelector('[data-preview]').textContent = m.text;
      document.querySelectorAll('[data-send]').forEach(function (a) { a.href = waLink(m.text); });
    }
    function render() {
      var l = lines();
      if (!l.length) { wrap.hidden = true; empty.hidden = false; updateBadges(); return; }
      wrap.hidden = false; empty.hidden = true;
      listEl.innerHTML = l.map(function (x) {
        return '<div class="cart-item"><div class="prod"><a class="thumb" href="product.html?id=' + x.p.id + '"><img src="' + IMG + x.p.img + '" alt="' + esc(x.p.name) + '"></a>' +
          '<div style="display:flex;flex-direction:column;gap:5px;min-width:0"><a class="name" href="product.html?id=' + x.p.id + '">' + esc(x.p.name) + '</a><span class="opts">' + esc(x.p.fabric !== '—' ? x.p.fabric : x.p.legs) + '</span><span>' + fmt(x.p.price) + ' ליחידה</span>' +
          '<button class="remove" type="button" data-remove="' + x.p.id + '">הסרה</button></div></div>' +
          '<div class="qty"><button type="button" aria-label="הוספת יחידה" data-q="' + x.p.id + '" data-d="1">+</button><span>' + x.qty + '</span><button type="button" aria-label="הפחתת יחידה" data-q="' + x.p.id + '" data-d="-1">−</button></div>' +
          '<b class="total">' + fmt(x.p.price * x.qty) + '</b></div>';
      }).join('');
      listEl.querySelectorAll('[data-q]').forEach(function (b) { b.addEventListener('click', function () { var c = readCart(); c.forEach(function (x) { if (x.id === b.getAttribute('data-q')) x.qty = Math.max(1, Math.min(9, x.qty + +b.getAttribute('data-d'))); }); writeCart(c); render(); }); });
      listEl.querySelectorAll('[data-remove]').forEach(function (b) { b.addEventListener('click', function () { writeCart(readCart().filter(function (x) { return x.id !== b.getAttribute('data-remove'); })); render(); }); });
      renderSummary();
    }
    render();
  }

  /* ---------- boot ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    var page = document.body.getAttribute('data-page');
    var h = document.querySelector('[data-header]'); if (h) h.outerHTML = header(document.body.getAttribute('data-nav'));
    var f = document.querySelector('[data-footer]'); if (f) f.outerHTML = footer();
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-add]'); if (t) { addToCart(t.getAttribute('data-add'), 1); return; }
      if (e.target.closest('[data-close-toast]')) { document.querySelector('[data-toast]').classList.remove('show'); return; }
      if (e.target.closest('[data-open-menu]')) { document.querySelector('[data-menu]').classList.add('open'); return; }
      if (e.target.closest('[data-close-menu]') || (e.target.closest('[data-menu] a'))) { document.querySelector('[data-menu]').classList.remove('open'); }
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { var m = document.querySelector('[data-menu]'); if (m) m.classList.remove('open'); var fl = document.querySelector('.filters'); if (fl) fl.classList.remove('open'); } });
    if (page === 'home') initHome();
    if (page === 'collection') initCollection();
    if (page === 'product') initProduct();
    if (page === 'cart') initCart();
    updateBadges();
  });
})();
